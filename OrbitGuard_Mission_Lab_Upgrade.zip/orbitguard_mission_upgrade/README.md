# OrbitGuard Pre-Cool — interactive mission demonstration upgrade

This is a **standalone addition** to your current OrbitGuard repository, not a replacement for its existing `index.html`, `app.js`, poster, or other files. The file `mission-lab.html` provides a touch-friendly demonstration for laptop and iPhone.

## Deploy into your existing GitHub site

1. Download `mission-lab.html` (or the ZIP) from ChatGPT.
2. Open your existing **mmisson-cloud/OrbitGuard** GitHub repository.
3. Choose **Add file → Upload files**, and upload **mission-lab.html** to the **repository root**. Commit the change to `main`.
4. When GitHub Pages updates, open **https://mmisson-cloud.github.io/OrbitGuard/mission-lab.html** in your browser.
5. To link it from your homepage, add `<a href="mission-lab.html">Launch Interactive Mission Lab</a>` inside the existing homepage where you want the link.
6. On your iPhone, use Safari to open the same URL. You can bookmark it or use Share → Add to Home Screen; that shortcut does **not** make this page a native iOS app.

Do not overwrite your existing `index.html` without checking it; this upgrade is a separate page.

## Three-minute demonstration

1. **The problem (30 seconds):** Dust contamination and radiator heat rejection compete on lunar equipment. The concept is advance-warning radiator-cover scheduling, not refrigeration or actual live lunar data.
2. **The baseline (30 seconds):** Run the standard scenario and point out the reactive control trace (blue), the Pre-Cool trace (mint), the shaded dust interval, and the 40°C demonstration boundary.
3. **The innovation (45 seconds):** Show the time open during the dusty interval for both controllers. Present that number as an **exposure-time proxy**, not measured dust deposition or demonstrated damage reduction.
4. **Stress test (40 seconds):** Click **Overheat stress test**. Explain that a good engineering system also identifies unsafe operating cases; reducing exposure time does not guarantee safe temperature.
5. **Uncertainty (35 seconds):** Choose **Early landing** to show how environmental timing affects warning-based control. Export the CSV to demonstrate that values are computed, not written into the graphic.

## What is actually implemented

- Responsive mission visualization with a movable/covered radiator illustration and a dust event cue.
- Forward-Euler single-node radiative temperature simulation evaluated for two controllers under the same heat loads, physical parameters, and time step.
- Interactive environmental and load inputs, live animated replay, temperature plots, modeled dust-interval radiator-open time, peak temperature, and comparative results.
- A transparent deterministic recommendation that flags overheating, no-benefit cases, and possible benefit; **no trained AI model or OpenAI API integration**.
- CSV export and optional browser text-to-speech.

## Physics and important boundaries

The model uses `C dT/dt = Q_in − εσA(T^4 − T_sink^4)` with `C=1800 J/K`, `A=0.06 m²`, `T_sink=3 K`, open emissivity `0.8`, covered emissivity `0.18`, and a ten-second numerical integration step. Initial modeled temperature is 33°C; dust is scheduled around mission minute 50 and lasts 10–40 minutes. Both controllers use a 34–36°C hysteresis; the Pre-Cool controller additionally opens the cover from its warning time up to the event. Once the dust interval starts, both use the same thermal hysteresis. Input parameters and the 40°C limit are illustrative, not spacecraft-specific verified constants.

This is a **concept experiment**. It does not model geometry, thermal conduction between components, the lunar surface radiative environment, incident sunlight, plume dynamics, dust adhesion, flight-certified control latency, hardware failures, dust sensor behavior, or physical cooling. Neither open-cover time nor modeled temperature directly validates spacecraft thermal safety or dust accumulation. Pre-Cool may not improve exposure in every scenario. The chart reflects numerical outputs and is **not** telemetry or NASA-derived experiment data.

### Optional next engineering milestones

- Independently validate results with measured thermal experiments, test model sensitivity to emissivity and heat capacity, and compare multiple numerical time steps.
- Build a tabletop motorized cover with servo, microcontroller, temperature sensor and safe power supply; label laboratory results as terrestrial analog tests.
- Add an optional **server-side** AI explanation API *after* the physics engine is validated; never place a secret OpenAI key in public GitHub Pages JavaScript.
- Improve to a multi-node, physically grounded lunar model, then clearly distinguish simulation from observation.

## Notes for judges

This is your own educational software proof of concept. NASA research can be cited as *inspiration*, but do not claim NASA approval, SpaceX AI use, actual NASA-data integration, operational flight readiness, or measured dust reduction without supporting implementation and evidence.
