# OrbitGuard Mission Lab — local numerical smoke test

JavaScript model executed using Node.js v22.16.0. These are outputs of this **new** controller implementation, not claims about the older Devpost screenshots.

| Scenario | Pre-Cool radiator open during dust | Reactive radiator open during dust | Pre-Cool peak | Reactive peak |
|---|---:|---:|---:|---:|
| 18 W; 10 min warning; scheduled landing | 17.83 min | 19.50 min | 36.06°C | 36.07°C |
| 30 W; 10 min warning; scheduled landing | 30.00 min | 30.00 min | 46.16°C | 46.16°C |
| 18 W; 10 min warning; landing 5 min early | 19.50 min | 19.50 min | 36.06°C | 36.07°C |

The default scenario's reduction is approximately **8.5%** in modeled radiator-open time, not the **71%** displayed in an earlier poster. Different controller assumptions, initial conditions, and timing produce different results. Do **not** mix numerical claims from separate versions. Before editing Devpost, choose a single model version and use its reproducible scenario outputs.

The page is not tested against physical spacecraft telemetry or lunar dust deposition. The Node check confirms the calculation executes, not that the physical assumptions are validated. Browser visual interaction was not tested in this environment.
